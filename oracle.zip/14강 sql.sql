DECLARE
    CURSOR emp_csr IS
    SELECT employee_id FROM employees
    WHERE department_id = 100;

    emp_id employees.employee_id%TYPE;

BEGIN
    FOR item IN emp_csr LOOP
        DBMS_OUTPUT.PUT_LINE( item.employee_id );
    END LOOP;
END;

BEGIN
    OPEN emp_csr;
    LOOP
        FETCH emp_csr INTO emp_id;
        EXIT WHEN emp_csr%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE( emp_id );
    END LOOP;
    CLOSE emp_csr;
END;

select * from employees;

drop procedure emp_register;

CREATE OR REPLACE PROCEDURE emp_register 
IS BEGIN     
INSERT INTO employees (employee_id, first_name, last_name, email, hire_date,job_id)     
VALUES (EMPLOYEES_SEQ.NEXTVAL,'HONGSEOK', 'NA', 'hsna99@cuk.edu',sysdate,'IT_PROG'); 
END;

CREATE OR REPLACE PROCEDURE emp_register                         
(f_name  VARCHAR2, l_name  VARCHAR2, e_mail VARCHAR2, j_id  VARCHAR2) 
IS 
BEGIN     
    INSERT INTO employees (employee_id, first_name, last_name, email, hire_date,job_id)     
    VALUES (EMPLOYEES_SEQ.NEXTVAL, f_name,  l_name,  e_mail, sysdate, j_id);     
    COMMIT;     
    EXCEPTION  WHEN  OTHERS  THEN 
        DBMS_OUTPUT.PUT_LINE('Register is failed'); 
        ROLLBACK; 
END; 

CREATE OR REPLACE PROCEDURE emp_register    
(f_name  VARCHAR2, l_name  VARCHAR2, e_mail VARCHAR2, j_id  VARCHAR2,  emp_id  OUT  NUMBER) 
IS 
BEGIN     
    emp_id := EMPLOYEES_SEQ.NEXTVAL;    --���߿� �� ���ν����� ȣ�����ʿ��� ��� ����. 
    INSERT INTO employees (employee_id, first_name, last_name, email, hire_date,job_id)    
    VALUES (emp_id, f_name,  l_name,  e_mail, sysdate, j_id);     
    COMMIT;    
    EXCEPTION  WHEN  OTHERS  THEN                
        DBMS_OUTPUT.PUT_LINE('Register is failed');               
        ROLLBACK; 
END; 

EXEC    emp_register; 
EXEC    emp_register('GILDONG','HONG','GDd@hmail.com','IT_PROG'); 

DECLARE
    e_id NUMBER;
BEGIN
    emp_register('MANHO','KANG','kmh@naver.com','IT_PROG',e_id);
    DBMS_OUTPUT.PUT_LINE(e_id);
END;

CREATE OR REPLACE   FUNCTION   emp_salaries (emp_id  NUMBER) 
RETURN  NUMBER  
IS nSalaries  NUMBER(9);
BEGIN     
    nSalaries := 0;     
    SELECT   salary    INTO  nSalaries   
    FROM employees     
    WHERE   employee_id  =  emp_id;     
    RETURN  nSalaries;
END;
