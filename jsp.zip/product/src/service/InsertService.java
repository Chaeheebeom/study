package service;

public class InsertService {

}
