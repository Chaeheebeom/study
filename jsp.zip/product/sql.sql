create table product(
	prcode int not null primary key,
	prname varchar(45) not null,
	price int not null,
	manufacture varchar(20) not null
);