create table board(
	board_num int not null, -- 글번호
	board_name varchar(20) not null,  -- 글쓴이
	board_pass varchar(15) not null,  -- 비밀번호
	board_subject varchar(50) not null, -- 글제목
	board_content varchar(2000) not null, -- 내용
	board_ori_file varchar(50),  -- 원래파일명
	board_re_file varchar(50),   -- 바뀐파일명
	board_re_ref int not null,   -- 답변글 달 때 참조 글번호
	board_re_lev int not null,   -- 답변글 깊이
	board_re_seq int not null,   -- 답변글 순서
	board_readcount int default 0,  -- 조회수
	board_date date,  -- 글쓴 날짜
	primary key(board_num)
);