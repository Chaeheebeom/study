package board.controller;

import board.action.impl.Action;
import board.action.impl.BoardDeleteAction;
import board.action.impl.BoardHitUpdateAction;
import board.action.impl.BoardInsertAction;
import board.action.impl.BoardListAction;
import board.action.impl.BoardModifyAction;
import board.action.impl.BoardPwdCheckAction;
import board.action.impl.BoardReplyAction;
import board.action.impl.BoardReplyViewAction;
import board.action.impl.BoardSearchAction;
import board.action.impl.BoardUpdateAction;
import board.action.impl.BoardViewAction;

public class BoardActionFactory {

	private static BoardActionFactory baf;
	private BoardActionFactory() {}
	
	public static BoardActionFactory getInstance() {
		if(baf==null)
			baf=new BoardActionFactory();
		return baf;
	}
	
	public Action action(String cmd) {
		Action action=null;
		if(cmd.equals("/qWrite.do")) {
			action=new BoardInsertAction("index.jsp");
		}else if(cmd.equals("/qList.do")) {
			action=new BoardListAction("view/qna_board_list.jsp");
		}else if(cmd.equals("/qView.do")) {
			action=new BoardViewAction("view/qna_board_view.jsp");
		}else if(cmd.equals("/qHitUpdate.do")) {
			action=new BoardHitUpdateAction("qView.do");
		}else if(cmd.equals("/qPwdCheck.do")) {
			action=new BoardPwdCheckAction("qDelete.do");
		}else if(cmd.equals("/qDelete.do")) {
			action=new BoardDeleteAction("qList.do");
		}else if(cmd.equals("/qModify.do")) {
			action=new BoardModifyAction("view/qna_board_modify.jsp");
		}else if(cmd.equals("/qUpdate.do")) {
			action=new BoardUpdateAction("qView.do");
		}else if(cmd.equals("/qReplyView.do")) {
			action=new BoardReplyViewAction("view/qna_board_reply.jsp");
		}else if(cmd.equals("/qReply.do")) {
			action=new BoardReplyAction("qList.do");
		}else if(cmd.equals("/search.do")) {
			action=new BoardSearchAction("view/qna_board_list.jsp");
		}
		return action;
	}
}










