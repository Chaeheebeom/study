package board.action.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dao.BoardDAO;

public class BoardDeleteAction implements Action {
	private String path;	
	
	public BoardDeleteAction(String path) {
		super();
		this.path = path;
	}


	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse res) {
		//BoardPwdCheckAction에서 넘기는 값 가져오기
		String board_num=req.getParameter("board_num");
		
		//board_num과 board_pass가 일치하는지 확인
		BoardDAO dao=new BoardDAO();
		int result=dao.deleteArticle(board_num);
		
		if(result==0)  //삭제에러
			path="";
		
		return new ActionForward(path, true);
	}

}
