package board.action.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dao.BoardDAO;
import board.vo.BoardVO;

public class BoardViewAction implements Action {
	private String path;
	
	public BoardViewAction(String path) {
		this.path=path;
	}
	
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse res) {
		
		//qHitUpdatae.do에서 넘어오는 값 가져오기(board_num)
		int board_num=Integer.parseInt(req.getParameter("board_num"));
		
		BoardDAO dao=new BoardDAO();
		
		
		//조회수 + 1 해주기
		//새로고침 시 조회수 계속 증가하기 때문에
		//다른 액션으로 분리시킴
		//int result=dao.setReadCountUpdate(board_num);
		
		
		
		//해당 board_num과 일치한 레코드 추출하기		
		BoardVO vo=dao.getRow(board_num);
		
		//추출된 레코드를 가지고 페이지 이동
		if(vo==null)
			path="qList.do";
		else
			req.setAttribute("vo", vo);
		
		return new ActionForward(path,false);
	}

}








