package board.action.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dao.BoardDAO;
import board.vo.BoardVO;

public class BoardModifyAction implements Action {
	private String path;	
	
	public BoardModifyAction(String path) {
		super();
		this.path = path;
	}	
	@Override
	public ActionForward execute(HttpServletRequest req,HttpServletResponse res)
			{
		
		int board_num=Integer.parseInt(req.getParameter("board_num"));
				
		BoardDAO dao=new BoardDAO();
		
		BoardVO vo=dao.getRow(board_num);
		
		if(vo!=null)
			req.setAttribute("vo", vo);
		
		
		return new ActionForward(path,false);
	}	
}
