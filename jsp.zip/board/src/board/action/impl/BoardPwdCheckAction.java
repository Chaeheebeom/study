package board.action.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dao.BoardDAO;

public class BoardPwdCheckAction implements Action {
	private String path;	
	
	public BoardPwdCheckAction(String path) {
		super();
		this.path = path;
	}


	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse res) {
		//qna_board_pwdcheck.jsp에서 넘기는 값 가져오기
		String board_num=req.getParameter("board_num");
		String board_pass=req.getParameter("board_pass");
		//board_num과 board_pass가 일치하는지 확인
		BoardDAO dao=new BoardDAO();
		int result=dao.pwdCheck(board_num, board_pass);
		
		if(result>0)
			path+="?board_num="+board_num;
		else
			path="";
		
		return new ActionForward(path, true);
	}

}
