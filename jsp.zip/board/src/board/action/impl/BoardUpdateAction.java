package board.action.impl;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import board.dao.BoardDAO;
import board.vo.BoardVO;
//수정하는 페이지에서 파일 삽입을 하는 경우에는 이렇게 하면 됨
//String board_file=multi.getOriginalFileName((String)multi.getFileNames().nextElement());
//이미 파일삽입을 한 상태라면 java.util.NoSuchElementException 뜸

public class BoardUpdateAction implements Action {
	private String path;	
	
	public BoardUpdateAction(String path) {
		super();//path : board/qna_board_list.jsp
		this.path = path;
	}	
	@Override
	public ActionForward execute(HttpServletRequest req,HttpServletResponse res)
	{
		
		//파일 업로드와 관련된 준비
		String saveDir="/upload";
		String uploadPath=req.getServletContext().getRealPath(saveDir);
		
		int size=5*1024*1024;
		MultipartRequest multi;		
		
		try {
			multi = new MultipartRequest(req, uploadPath,size,"UTF-8",
					new DefaultFileRenamePolicy());
		
			//폼 데이터 가져오기	=> 
			String board_num=multi.getParameter("board_num");
			String board_pass=multi.getParameter("board_pass");
			String board_content=multi.getParameter("contents");
			String board_subject=multi.getParameter("board_subject");			
			
			BoardVO vo=new BoardVO();
			vo.setBoard_num(Integer.parseInt(board_num));
			vo.setBoard_pass(board_pass);
			vo.setBoard_content(board_content);
			vo.setBoard_subject(board_subject);
					
			@SuppressWarnings("unchecked")
			Enumeration<String> names=multi.getFileNames();	
						
			boolean flag=false;
			//수정하는 페이지에서 파일 삽입이 안들어오는 경우와 들어오는 경우
			if(names.hasMoreElements()) {	
				String board_file=names.nextElement();
				flag=true;
				vo.setBoard_ori_file(multi.getOriginalFileName(board_file));				
				vo.setBoard_re_file(multi.getFilesystemName(board_file));			
			}			
			
			BoardDAO dao=new BoardDAO();
			//수정하기 버튼을 클릭한 경우에는 조회수 업데이트 안함
			//비밀번호가 맞는지 체크한 후 
			int result=dao.pwdCheck(board_num,board_pass);
			
			//실제 수정인 경우 flag
			if(result>0) {//비밀번호가 맞는다면 업데이트 후 수정된 내용 보여주기
				if(flag) {
					dao.updateRow(vo,flag);
				}else {
					dao.updateRow(vo);
				}				
				path+="?board_num="+board_num;
			}
		} catch (IOException e) {			
			e.printStackTrace();
		}				
		return new ActionForward(path,true); 
	}	
}
