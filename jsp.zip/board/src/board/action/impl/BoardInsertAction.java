package board.action.impl;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import board.dao.BoardDAO;
import board.vo.BoardVO;

public class BoardInsertAction implements Action {
	private String path;
	
	public BoardInsertAction(String path) {
		this.path=path;
	}	
	@Override
	public ActionForward execute(HttpServletRequest req, 
			HttpServletResponse res) {
		//qna_board_write.jsp에서 넘어오는 값 가져오기
		
		//파일 업로드와 관련된 준비
		String saveDir="/upload";
		String uploadPath=req.getServletContext().getRealPath(saveDir);		
		int size=5*1024*1024;
		MultipartRequest multi;				
		try {
			multi = new MultipartRequest
					(req, uploadPath,size,"UTF-8",
							new DefaultFileRenamePolicy());
				
			//폼 데이터 가져오기
			BoardVO vo=new BoardVO();
			vo.setBoard_name(multi.getParameter("board_name"));
			vo.setBoard_subject(multi.getParameter("board_subject"));
			vo.setBoard_content(multi.getParameter("board_content"));
			vo.setBoard_pass(multi.getParameter("board_pass"));			
						
			//중복된 파일명 
			String fileName=(String)multi.getFileNames().nextElement();
			vo.setBoard_ori_file(multi.getOriginalFileName(fileName));	
			vo.setBoard_re_file(multi.getFilesystemName(fileName));	
					
			
			//DAO 작업			
			BoardDAO dao=new BoardDAO();
			//테이블에 삽입하기
			int result=dao.insertArticle(vo);
			if(result==0) {
				path="board/qna_board_write_error.jsp";
			}
		} catch (IOException e) {			
			e.printStackTrace();
		}
		//삽입완료 후 index 페이지로 이동	
		return new ActionForward(path,true);		
		
	}
}
