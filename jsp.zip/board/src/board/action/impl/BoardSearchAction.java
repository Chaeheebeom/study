package board.action.impl;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import board.dao.BoardDAO;
import board.vo.BoardVO;
import board.vo.PageInfo;

public class BoardSearchAction implements Action {
	private String path;	
	
	public BoardSearchAction(String path) {
		super();//path : board/qna_board_list.jsp
		this.path = path;
	}	
	@Override
	public ActionForward execute(HttpServletRequest req,HttpServletResponse res)
	{
		
		//qna_board_list에서 넘어오는 값 가져오기
		String criteria=req.getParameter("criteria");
		String searchword=req.getParameter("searchword");
		
		
		int page=1;
		
		if(req.getParameter("page")!=null)
			page=(Integer.parseInt(req.getParameter("page")));
		
		//검색기준과 검색어에 맞는 전체 레코드 갯수 가져오기
		BoardDAO dao=new BoardDAO();
		int totalRows=dao.getRows(criteria, searchword);
		
		
		//한 페이지에 보여줄 목록 갯수
		int limit=10;
		
		//총 페이지 수
		// ex) totalRows = 300 일때
		//  300.0/10 = 30.0+0.95 = 30.95 = 30
		//    9.0/10 = 0.9+0.95 = 1.85  = 1
		int totalPage=(int)((double)totalRows/limit+0.95);
		
		
		//사용자가 누르는 페이지 번호에 맞춰 읽어올 
		//레코드의 시작번호와 끝번호 계산
		int startPage=(((int)((double)page/10+0.9))-1)*10+1;
		int endPage=startPage+10-1;
		
		if(endPage>totalPage)
			endPage=totalPage;
		
		//계산된 결과를 페이지 정보에 담기
		PageInfo info=new PageInfo();
		info.setEndPage(endPage);
		info.setTotalPage(totalPage);
		info.setPage(page);
		info.setStartPage(startPage);
		info.setTotalRows(totalRows);	
		
				
		//dao에서 조건에 맞는 리스트 가져오기
		Vector<BoardVO> list=dao.getSearchList(page,limit,criteria, searchword);	
		//검색된 리스트를 담고 페이지 이동
		if(!list.isEmpty()) {
			req.setAttribute("list", list);
			req.setAttribute("criteria", criteria);
			req.setAttribute("searchword", searchword);
			req.setAttribute("info", info);
			
		}
		return new ActionForward(path,false); 
	}	
}









