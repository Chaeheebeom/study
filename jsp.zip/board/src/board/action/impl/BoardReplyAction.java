package board.action.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dao.BoardDAO;
import board.vo.BoardVO;

public class BoardReplyAction implements Action {
	private String path;
	
	public BoardReplyAction(String path) {
		this.path=path;
	}
	
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse res) {
		
		//qna_board_reply에서 넘어오는 값 가져오기
		//폼에서 넘어오는 값 가져오기
		String board_subject=req.getParameter("board_subject");
		String board_name=req.getParameter("board_name");
		String board_content=req.getParameter("board_content");
		String board_pass=req.getParameter("board_pass");
		
		System.out.println(board_content+"컨텐츠");
		System.out.println(board_subject+"제");
		
		
		
				
		//hidden 으로 숨긴 원본글에 대한 정보 가져오기
		int board_num=Integer.parseInt(req.getParameter("board_num"));
		int board_re_ref=Integer.parseInt(req.getParameter("board_re_ref"));
		int board_re_lev=Integer.parseInt(req.getParameter("board_re_lev"));
		int board_re_seq=Integer.parseInt(req.getParameter("board_re_seq"));
		
		
		BoardDAO dao=new BoardDAO();		
		BoardVO vo=new BoardVO();
		vo.setBoard_subject(board_subject);
		vo.setBoard_name(board_name);
		vo.setBoard_content(board_content);
		vo.setBoard_pass(board_pass);
		vo.setBoard_re_ref(board_re_ref);
		vo.setBoard_re_lev(board_re_lev);
		vo.setBoard_re_seq(board_re_seq);
		//		
		int result=dao.boardReply(vo);
		
		//추출된 레코드를 가지고 페이지 이동
		if(result==0)
			path="";
		
		return new ActionForward(path,true);
	}

}








