package board.action.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dao.BoardDAO;
import board.vo.BoardVO;

public class BoardReplyViewAction implements Action {
	private String path;
	
	public BoardReplyViewAction(String path) {
		this.path=path;
	}
	
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse res) {
		
		//qna_board_view에서 넘어오는 값 가져오기(board_num)
		int board_num=Integer.parseInt(req.getParameter("board_num"));
		
		BoardDAO dao=new BoardDAO();		
		
		//해당 board_num과 일치한 레코드 추출하기		
		BoardVO vo=dao.getRow(board_num);
		
		//추출된 레코드를 가지고 페이지 이동
		if(vo!=null)
			req.setAttribute("vo", vo);
		else
			path="";
		
		return new ActionForward(path,false);
	}

}








