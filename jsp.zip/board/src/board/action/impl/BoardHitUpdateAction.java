package board.action.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dao.BoardDAO;

public class BoardHitUpdateAction implements Action {

	private String path;	
	
	public BoardHitUpdateAction(String path) {
		super();
		this.path = path;
	}

	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse res) {
		
		int board_num=Integer.parseInt(req.getParameter("board_num"));
		
		BoardDAO dao=new BoardDAO();
		//조회수 + 1 해주기
		int result=dao.setReadCountUpdate(board_num);
		if(result>0) {
			path+="?board_num="+board_num;
		}else {
			path="";
		}
		return new ActionForward(path,true);
	}

}










