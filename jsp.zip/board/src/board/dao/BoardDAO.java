package board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import board.vo.BoardVO;

public class BoardDAO {
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;	
	
	public Connection getConnection() {
		DataSource ds=null;
		try {
			Context ctx=new InitialContext();
			ds=(DataSource) ctx.lookup("java:comp/env/jdbc/MySQL");
			con=ds.getConnection();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public void close(Connection con, PreparedStatement pstmt) {
		try {
			if(pstmt!=null) pstmt.close();
			if(con!=null)	con.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void close(Connection con, PreparedStatement pstmt,ResultSet rs) {
		try {
			if(rs!=null) rs.close();
			if(pstmt!=null) pstmt.close();
			if(con!=null)	con.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public int insertArticle(BoardVO vo) {
		int result=0;
		int num=0;
		try {
			con=getConnection();
			con.setAutoCommit(false);
			//글 번호 가져오기			
			String sql="select max(board_num) from board";
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			
			if(rs.next()) {
				num=rs.getInt(1)+1;
			}else {
				num=1;
			}
			
			//insert 작업 시작
			sql="insert into board values(?,?,?,?,?,?,?,?,?,?,?,now())";
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, vo.getBoard_name());
			pstmt.setString(3, vo.getBoard_pass());
			pstmt.setString(4, vo.getBoard_subject());
			pstmt.setString(5, vo.getBoard_content());
			pstmt.setString(6, vo.getBoard_ori_file());
			pstmt.setString(7, vo.getBoard_re_file());
			pstmt.setInt(8, num); //board_re_ref
			pstmt.setInt(9, 0); //board_re_lev
			pstmt.setInt(10, 0); //board_re_seq
			pstmt.setInt(11, 0);			
			
			result=pstmt.executeUpdate();
			if(result>0)
				con.commit();
		}catch(SQLException e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			close(con,pstmt,rs);
		}
		return result;
	}
	
	//전체 리스트 가져오기
	public Vector<BoardVO> getList(int page,int limit){
		
		//시작레코드 번호 구하기
		int start=(page-1)*10;
		
		Vector<BoardVO> list=new Vector<BoardVO>();
		StringBuffer sql=new StringBuffer();
		sql.append("select * ");		
		sql.append(" from board order by board_re_ref desc, board_re_seq asc limit ?,?");
		try {
			con=getConnection();
			pstmt=con.prepareStatement(sql.toString());
			pstmt.setInt(1, start);
			pstmt.setInt(2, limit);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				BoardVO vo=new BoardVO();
				vo.setBoard_num(rs.getInt(1));
				vo.setBoard_name(rs.getString(2));
				vo.setBoard_subject(rs.getString(4));				
				vo.setBoard_readcount(rs.getInt(11));
				vo.setBoard_date(rs.getDate(12));
				list.add(vo);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(con,pstmt,rs);
		}
		return list;
	}
	public BoardVO getRow(int board_num) {
		
		BoardVO vo=null;
		try {
			con=getConnection();
			String sql="select * from board where board_num=?";
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, board_num);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				vo=new BoardVO();
				vo.setBoard_num(rs.getInt("board_num"));
				vo.setBoard_name(rs.getString("board_name"));
				vo.setBoard_subject(rs.getString("board_subject"));
				vo.setBoard_content(rs.getString("board_content"));
				vo.setBoard_ori_file(rs.getString("board_ori_file"));
				vo.setBoard_re_file(rs.getString("board_re_file"));
				vo.setBoard_re_ref(rs.getInt("board_re_ref"));
				vo.setBoard_re_lev(rs.getInt("board_re_lev"));
				vo.setBoard_re_seq(rs.getInt("board_re_seq"));				
			}
		}catch(SQLException e) {
			
		}finally {
			close(con,pstmt,rs);
		}
		return vo;
	}
	//조회수 업데이트
	public int setReadCountUpdate(int board_num) {
		String sql="update board set board_readcount=board_readcount+1";
		sql+=" where board_num=?";
		int result=0;
		try {
			con=getConnection();
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, board_num);
			result=pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(con,pstmt);
		}
		return result;
	}
	//비밀번호 맞는지 체크(수정,삭제시 이용)
	public int pwdCheck(String board_num,String board_pass) {
		int result=0;
		String sql="select * from board where board_pass=? and board_num=?";
		try {
			con=getConnection();
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, board_pass);
			pstmt.setInt(2, Integer.parseInt(board_num));
			rs=pstmt.executeQuery();
			if(rs.next()) {
				result=1;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(con,pstmt,rs);
		}	
		
		return result;
	}
	
	//게시물 삭제
	public int deleteArticle(String board_num) {
		int result=0;
		
		String sql="delete from board where board_num=?";
		try {
			con=getConnection();
			pstmt=con.prepareStatement(sql);			
			pstmt.setInt(1, Integer.parseInt(board_num));
			result=pstmt.executeUpdate();			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(con,pstmt,rs);
		}	
		
		return result;
	}
	//게시판 내용 수정
	public int updateRow(BoardVO vo,boolean flag) {

		String sql="update board set board_content=?, board_subject=?,"
				+ " board_ori_file=?,"
				+ "board_re_file=? where board_num=?";
		int result=0;
		try {
				con=getConnection();			
				pstmt=con.prepareStatement(sql);
				pstmt.setString(1, vo.getBoard_content());
				pstmt.setString(2, vo.getBoard_subject());
				pstmt.setString(3, vo.getBoard_ori_file());
				pstmt.setString(4, vo.getBoard_re_file());
				pstmt.setInt(5, vo.getBoard_num());
				result=pstmt.executeUpdate();				
		}catch (SQLException e) {
				e.printStackTrace();
		}finally {
			close(con,pstmt,rs);
		}
		return result;
	}
	//게시판 내용 수정-board_file이 원래 있는 경우
	public boolean updateRow(BoardVO vo) {

		String sql="update board set board_content=?, board_subject=? "
				+ "where board_num=?";
		boolean flag=false;
		try {
				con=getConnection();
				pstmt=con.prepareStatement(sql);
				pstmt.setString(1, vo.getBoard_content());
				pstmt.setString(2, vo.getBoard_subject());
				pstmt.setInt(3, vo.getBoard_num());
				int result=pstmt.executeUpdate();
				if(result>0) {
					flag=true;
				}
		}catch (SQLException e) {
				e.printStackTrace();
		}finally {
			close(con,pstmt);
		}
		return flag;
	}
	
	//답변글
	public int boardReply(BoardVO vo) {
		//원본글의 hidden에 들어 있었던 값
		int re_ref=vo.getBoard_re_ref();
		int re_lev=vo.getBoard_re_lev();
		int re_seq=vo.getBoard_re_seq();	
		
		
		//답변글 넣기 위해  글 번호 하나 가져오기
		String sql_num="select max(board_num) from board";
		int num=0;
		int result=0;
		try {
			con=getConnection();
			pstmt=con.prepareStatement(sql_num);
			rs=pstmt.executeQuery();
			if(rs.next())
				num=rs.getInt(1)+1;
			else
				num=1;
			
		//답변글과 같은 그룹에 속하는 글들의 update 실행
		String sql="update board set board_re_seq=board_re_seq+1 ";
		sql+="where board_re_ref=? and board_re_seq>?";
		pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, re_ref);
		pstmt.setInt(2, re_seq);
		pstmt.executeUpdate();
		re_seq=re_seq+1;
		re_lev=re_lev+1;
		
			
		//답변글 삽입
		String ins_sql="insert into board(board_num,board_name,board_pass,"
				+ "board_subject,board_content,board_re_ref,board_re_lev,board_re_seq,"
				+ "board_readcount,board_date) "
				+ "values(?,?,?,?,?,?,?,?,?,now())";
		pstmt=con.prepareStatement(ins_sql);
		pstmt.setInt(1, num);
		pstmt.setString(2, vo.getBoard_name());
		pstmt.setString(3, vo.getBoard_pass());
		pstmt.setString(4, vo.getBoard_subject());		
		pstmt.setString(5, vo.getBoard_content());
		pstmt.setInt(6, re_ref);
		pstmt.setInt(7, re_lev);
		pstmt.setInt(8, re_seq);
		pstmt.setInt(9, 0);		
		result=pstmt.executeUpdate();		
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(con,pstmt);
		}
		return result;
	}
	//검색 리스트
	public Vector<BoardVO> getSearchList(int page,int limit,String criteria,String searchword){
		int start=(page-1)*10;
		
		Vector<BoardVO> list=new Vector<BoardVO>();
		StringBuffer sql=new StringBuffer();
		sql.append("select * ");		
		sql.append(" from board where  "+criteria+" like ?");
		sql.append(" order by board_re_ref desc, board_re_seq asc limit ?,?");
		try {
			con=getConnection();
			pstmt=con.prepareStatement(sql.toString());
			pstmt.setString(1, "%"+searchword+"%");
			pstmt.setInt(2, start);
			pstmt.setInt(3, limit);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				BoardVO vo=new BoardVO();
				vo.setBoard_num(rs.getInt(1));
				vo.setBoard_name(rs.getString(2));
				vo.setBoard_subject(rs.getString(4));				
				vo.setBoard_readcount(rs.getInt(11));
				vo.setBoard_date(rs.getDate(12));
				list.add(vo);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(con,pstmt,rs);
		}
		return list;
	}
	//전체 레코드 갯수 구하기
	public int getRows() {
		String sql="select count(*) from board";
		int total_rows=0;
		try {
			con=getConnection();
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			if(rs.next())
				total_rows=rs.getInt(1);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(con,pstmt,rs);
		}
		return total_rows;
	}
	
	public int getRows(String criteria,String searchword) {
		String sql="select count(*) from board where ";
		sql+=criteria+ " like ? order by board_re_ref desc,board_re_seq asc";
		int total_rows=0;
		try {
			con=getConnection();
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, "%"+searchword+"%");
			rs=pstmt.executeQuery();
			if(rs.next())
				total_rows=rs.getInt(1);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(con,pstmt,rs);
		}
		return total_rows;
	}
}




















